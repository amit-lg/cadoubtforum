import { Link, useLocation } from "react-router-dom";
import PropTypes from "prop-types";
import {
  closeMobileSidebar,
  setSearchText,
} from "../redux/reducers/appReducer";
import { useDispatch, useSelector } from "react-redux";
import { clearFilters as clearAllQuestionFilters } from "../redux/reducers/allQuestionsReducer";
import { clearFilters as clearAskedQuestionFilters } from "../redux/reducers/askedQuestionsReducer";
import { clearFilters as clearPinnedQuestionFilters } from "../redux/reducers/pinnedQuestionsReducer";
import { clearFilters as clearUnansweredQuestionFilters } from "../redux/reducers/unansweredQuestionsReducer";

const SidebarLink = ({ route, location }) => {
  const { collapsedSidebar } = useSelector((state) => state.app);

  const routeLocation = useLocation();

  const dispatch = useDispatch();
  const closeSidebar = () => {
    dispatch(closeMobileSidebar());
    if (routeLocation.pathname !== "/all-questions") {
      dispatch(clearAllQuestionFilters());
    }

    if (routeLocation.pathname !== "/asked-questions") {
      dispatch(clearAskedQuestionFilters());
    }

    if (routeLocation.pathname !== "/pinned-questions") {
      dispatch(clearPinnedQuestionFilters());
    }

    if (routeLocation.pathname !== "/unanswered-questions") {
      dispatch(clearUnansweredQuestionFilters());
    }

    dispatch(setSearchText(""));
  };

  return (
    <Link
      onClick={closeSidebar}
      id={route.id}
      key={route.href}
      to={route.href}
      className={`
      ${!collapsedSidebar ? "m-1" : "my-1"} 
      text-sm group flex p-3
      ${collapsedSidebar ? "w-max mx-auto" : "w-full justify-start"} 
      font-medium cursor-pointer hover:text-white hover:bg-white/30 rounded-lg transition 
      ${location.pathname === route.href ? "bg-blue-600" : ""}`}
    >
      <div
        className={`
          flex items-center flex-1
          ${collapsedSidebar ? "flex-col" : "flex-row"}
        `}
      >
        {location.pathname === route.href ? (
          <route.selectedIcon
            className={`w-5 h-5 ${collapsedSidebar ? "mr-0" : "mr-3"}`}
          />
        ) : (
          <route.icon
            className={`w-5 h-5 ${collapsedSidebar ? "mr-0" : "mr-3"}`}
          />
        )}

        {!collapsedSidebar && (
          <span
            className={`delay font-${
              location.pathname === route.href ? "semibold" : "medium"
            } text-sm text-center `}
          >
            {route.label}
          </span>
        )}
      </div>
    </Link>
  );
};

export default SidebarLink;

SidebarLink.propTypes = {
  route: PropTypes.object,
  location: PropTypes.object,
};
