
const ForgetPasswordForm = () => {
  return (
    <div>ForgetPasswordForm</div>
  )
}

export default ForgetPasswordForm