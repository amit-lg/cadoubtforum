
const AdminOnly = () => {
  return (
    <div>AdminOnly</div>
  )
}

export default AdminOnly