import React from 'react'

const NoItems = () => {
  return (
    <div>NoItems</div>
  )
}

export default NoItems