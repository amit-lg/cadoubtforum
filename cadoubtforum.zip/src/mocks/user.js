export const user = {
    firstName : "John",
    lastName : "Doe",
    email : "johndoe@gmail.com",
    phone : 9876543210,
    image : "https://images.unsplash.com/photo-1633332755192-727a05c4013d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OHx8YXZhdGFyfGVufDB8fDB8fHww&w=1000&q=80",
    role : "Software Engineer",
    bio : "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.  ",
    links : {
        twitter : "https://twitter.com/johndoe",
        linkedin : "https://linkedin.com/johndoe",
        instagram : "https://instagram.com/johndoe",
        facebook : "https://facebook.com/johndoe",
    }
}