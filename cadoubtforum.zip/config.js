export const backendUrl = import.meta.env.VITE_BACKEND_URL;
export const socketUrl = import.meta.env.VITE_SOCKET_URL;
export const dAuth = import.meta.env.VITE_D_AUTH;
