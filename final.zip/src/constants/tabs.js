export const tabs = [
  {
    name: "General Questions",
    value: "general",
  },
  {
    name: "Posting a Doubt",
    value: "posting",
  },
  {
    name: "Moderation & Guidelines",
    value: "moderation",
  },
  {
    name: "Technical Issues",
    value: "technical",
  },
];

export const calenderTabs = [
  {
    name: "Dates",
    value: "dates",
  },
  {
    name: "Goals",
    value: "goals",
  },
];
