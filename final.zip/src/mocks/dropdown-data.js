export const dropdownData = [
    "sunt in culpa qui officia deserunt mollit anim id est laborumsunt in culpa qui officia deserunt mollit anim id est laborumsunt in culpa qui officia deserunt mollit anim id est laborumsunt in culpa qui officia deserunt mollit anim id est laborumsunt in culpa qui officia deserunt mollit anim id est laborum",

    "sunt in culpa qui officia deserunt mollit anim id est laborumsunt in culpa qui officia deserunt mollit anim id est laborumsunt in culpa qui officia deserunt mollit anim id est laborumsunt in culpa qui officia deserunt mollit anim id est laborumsunt in culpa qui officia deserunt mollit anim id est laborum",

    "sunt in culpa qui officia deserunt mollit anim id est laborumsunt in culpa qui officia deserunt mollit anim id est laborumsunt in culpa qui officia deserunt mollit anim id est laborumsunt in culpa qui officia deserunt mollit anim id est laborumsunt in culpa qui officia deserunt mollit anim id est laborum",

    "sunt in culpa qui officia deserunt mollit anim id est laborumsunt in culpa qui officia deserunt mollit anim id est laborumsunt in culpa qui officia deserunt mollit anim id est laborumsunt in culpa qui officia deserunt mollit anim id est laborumsunt in culpa qui officia deserunt mollit anim id est laborum",

]