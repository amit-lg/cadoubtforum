export const backendUrl = import.meta.env.VITE_BACKEND_URL;
export const dAuth = import.meta.env.VITE_D_AUTH;
